Upload index.json and every archive/part named in it. manifest.json and this README are optional.
The original run is unchanged. Do not remove it. The review package is an explicit subset.
Verify: bash scripts/compact_review.sh verify <this-directory>/index.json
Restore: bash scripts/compact_review.sh unpack <this-directory>/index.json --output runs/review-restored
No concatenated full archive is needed by these commands.
