# Tangent research metric legend

**RMS / MSE**: Physical root-mean-square / mean-squared field error. FD uses nodal weighting; Galerkin uses its physical interpolant and Nyquist weights. Paired descendants are not independent parents.

**maximum**: Largest sampled absolute physical error; not a continuous supremum certificate.

**mean / centered**: Spatial-average error and error remaining after mean removal. Their squared contributions and signed cross terms retain their actual source definitions.

**G / U**: Matched anchor-mean response / spatially varying tangent response on the same smooth FP64 anchor and physical residual.

**action / rank**: Matrix-free response applied to a predeclared source direction / retained response-factor dimension. Probe count is work, not independent population count; vector fit rank is not operator rank.

**uncertainty / headroom**: Empirical teacher/path/tangent refinement estimates and measurable signal above those estimates/output rounding. Not certified bounds or confidence intervals. All requested/null/rejected slots remain in raw source coverage.

**conditioning**: Singular values, declared cutoff/ridge, factor/Gram scales and sensitivity in actual deployment precision. Conditional least squares does not prove a nonlinear global optimum.

**training / validation**: Full-parent physical objectives and actual optimizer commits. Validation selects deployment; initialization/final/best-training fits remain distinct. No old 100-fold rule is applied.

**physical / arithmetic bridge**: Teacher64 minus smooth anchor64 / smooth anchor64 minus deployed FP32 anchor. Final FP32 addition and numerical remainder are separately named and costed.

**rollout / composition**: Re-encoded autonomous macrosteps and intermediate teachers / a separately measured composition difference. Stable finite values do not imply accuracy.

**cost / telemetry**: Offline labels, optimizer/stage/worker/allocation and complete inference scopes remain separate. CPU/RSS snapshots exclude departed/remote processes; GPU samples are allocated-device counters, not per-process VRAM accounting. Null means unavailable; zero is observed. No energy/monetary inference from latency.

**CPU utilization / RSS / VRAM**: CPU percent uses a single logical core as 100% and may exceed 100%; process-tree changes leave interval utilization unavailable. RSS is resident host memory and can count shared pages repeatedly. VRAM is whole assigned-device memory, including any display/co-resident processes.

**public observations / optimizer journal**: Scheduled learning rows are exported observations, not every private optimizer commit. Resource charts use at most 256 uniform observations per retained worker stream; full raw JSONL remains copied and cited. Whole-history optimizer summaries retain their producer's exact scope.

**PASS / STOP / UNRESOLVED / IMPLEMENTATION_ONLY**: The unchanged serialized prospective gate / negative evidence / insufficient valid evidence / reduced software verification with no native promotion.
