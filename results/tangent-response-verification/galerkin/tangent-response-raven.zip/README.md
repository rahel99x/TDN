# Tangent-response research

Register this directory with `:project PATH`. The overview preserves every registered method, missing unit and negative gate. Large campaigns use page-000 and later separate detail projects below Raven's discovery cap. Native attempts carry actual worker job IDs; the aggregate overview has none.

Only research metadata, CSV/JSON, plots and retained resource streams are exported. Binary teachers/checkpoints/journals remain in the native run; the omission inventory retains their hashes. CPU implementation checks do not establish CUDA readiness or scientific promotion.
